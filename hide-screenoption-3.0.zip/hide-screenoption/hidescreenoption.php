<?php
/*
Plugin Name: Hide ScreenOption
Description: Hide field from Screen Options for Editors
Author: Jasper Scaff
Version: 3.0
*/

class HideScreenOption {

    /** Refers to a single instance of this class. */
    private static $instance = null;

    /**
     * Creates or returns an instance of this class.
     *
     * @return  A single instance of this class.
     */
    public static function get_instance() {

        if ( null == self::$instance ) {
            self::$instance = new self;
        }

        return self::$instance;

    }
    /**
     * Initializes the plugin by setting localization, filters, and administration functions.
     */
    private function __construct() {
        add_action('do_meta_boxes', array( $this, 'remove_metaboxes' ), 1000, 3);
        add_filter( 'hidden_meta_boxes',  array( $this, 'show_metaboxes' ), 10, 3);  
    }
    
    function remove_metaboxes($post_type, $type, $post) {
        global $wp_meta_boxes, $current_user;

        if ( is_user_logged_in() ) {
            $userRole = $current_user->roles;
            if (in_array('editor', $userRole)) {
                $default_columns=array('authordiv','tagsdiv-post_tag','categorydiv','formatdiv','submitdiv');
                if ($post_type == 'post') {
                    $post_meta_boxes = $wp_meta_boxes['post'];
                    foreach ($post_meta_boxes as $key => $value) {
                        foreach ($value as $key1 => $value1) {
                            foreach ($value1 as $key2 => $value2) {
                                if (!in_array($key2,$default_columns)) {
                                    unset($wp_meta_boxes['post'][$key][$key1][$key2]);
                                }
                            }
                        }
                    }
                }
            }
        }
    }
    function show_metaboxes($hidden, $screen, $use_defaults) {
        global $current_user;
        if( is_user_logged_in()) {
            $userRole = $current_user->roles;
            if (in_array('editor', $userRole)) {
                foreach ($hidden as $key => $value) {
                    if ($value == 'authordiv')
                        unset($hidden[$key]);
                }   
                    
            }   
        }
        return $hidden;   
    }
}

HideScreenOption::get_instance();
